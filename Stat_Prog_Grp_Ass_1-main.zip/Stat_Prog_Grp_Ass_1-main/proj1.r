# s1704264 Benedict Troy
# s2451950 Scott Jenkins
# s2453724 Emily Segers

# Contribution:
# None of us contributed significantly more, or less, than the others. 
# Hence we deserve equal marks on this assignment. 

########################################################################

setwd("~/Desktop/git_files/Stat_Prog/Stat_Prog_Grp_Ass_1")

# Load the data in. Source: https://www.gutenberg.org/ebooks/10
a <- scan("pg10.txt",what="character",skip=104) ## skip contents 
n <- length(a)
a <- a[-((n-2886):n)] ## strip license
a <- a[-grep("[0123456789]:[0123456789]",a)] ## strip out verse numbers


## Q4 ##
a <- strsplit(a , " ") 
#Create function split_punct that takes a vector and a punctuation. 
#The function splits the punctuation from the word.
split_punct <- function(word, punc){
  punc_removed <- gsub(punc, "", word) #removes the punctuation
  if (length(grep(punc, word)) == 1){ #if word contains the punctuation mark, remove and re-add punctuation
    punc_separated <- append(punc_removed, substr(punc, nchar(punc), nchar(punc)))
  }else{
    punc_separated <- word
  }  
}



## Q5 ##
print("It takes a couple of minutes to run our split punct function...")
punctuation <- c(",", "!", ":", ";", "\\?", "\\.")
#apply split_punct to the bible
for(p in punctuation){
  a <- lapply(a, function(x) split_punct(x,p)) 
}

a <- unlist(a)


## Q6 ##
## Store a copy of the bible before making lower case, ready for Q10
bible_original <- a

a <- tolower(a) #make the bible lower case 

unique_vec <- unique(a) #search unique words             

index_u_vec <- match(a, unique_vec)  #matches word in 'a' to index of word in unique

tab_vec <- tabulate(bin = index_u_vec) #for each element in index_vec counts the frequency of occurrence in a. 
                                     
threshold<- sort(tab_vec, decreasing = TRUE)[500] #sort from high to low and take the 500th term.


#Create vector b with most common words. A word is common if the occurrence in the bible is bigger than treshold.
b <- unique_vec[tab_vec > threshold] 

b_length <- length(b) #need this to define the sizes of T, A and S

## Q7 ##

#A
index_b_vec <- match(a, b) #shows where each word from bible is stored in common words. If NA, then not in b
                                
#B
word_total <- length(a)

#create columns that contain the word indices
col_1 <- index_b_vec                                
col_2 <- c(NA,index_b_vec[1:(word_total - 1)])
col_3 <- c(NA,NA,index_b_vec[1:(word_total - 2)])

#combine the columns
rolling_matrix <- cbind(col_3,col_2,col_1)

#C
#method to delete the rows that contains NA (not common words)
row_sums <- rowSums(is.na(rolling_matrix))
useful_matrix <- rolling_matrix[row_sums == 0, 1:3] #useful means only contains common words
useful_row_count <-dim(useful_matrix)[1] #the number of rows in our useful_matrix

#D
T <- array(0,rep(b_length,3)) #initialize matrix T

#fill T with the number of times three words follow each other in the bible
for (i in 1:useful_row_count) { 
  T[useful_matrix[[i,1]],useful_matrix[[i,2]],useful_matrix[[i,3]]] <- T[useful_matrix[[i,1]],useful_matrix[[i,2]],useful_matrix[[i,3]]] + 1
}

#F
#Creating A. Done similarly as T
rolling_matrix_A <- cbind(col_2,col_1)  
row_sums_A <- rowSums(is.na(rolling_matrix_A)) 
useful_matrix_A <- rolling_matrix_A[row_sums_A == 0, 1:2]
useful_row_count_A <-dim(useful_matrix_A)[1]

A <- array(0,rep(b_length,2)) #initialize matrix A 

#fill A with the number of times two words follow each other in the bible
for (i in 1:useful_row_count_A) {
  A[useful_matrix_A[[i,1]],useful_matrix_A[[i,2]]] <- A[useful_matrix_A[[i,1]],useful_matrix_A[[i,2]]] + 1    ## Add one to this spot in the array
}


# Create S. Counts the number of times a word occurs in b
S <- tabulate(bin = index_b_vec)         
which(S < 145) #test: elements of S greater than 145



## Q8 ##

simulated_indices <- c() #initialize list

# draw first word. For the first word S is used as a prob since it follows no other words.
first_index <- sample(1:length(b), 1, prob = S)
simulated_indices <- append(simulated_indices, first_index) 

# draw second word. 
if (sum(A[first_index, ]) > 0){ #case where a word follows first_index. Draw second word with prob A
  second_index <- sample(1:length(b), 1, prob = A[first_index, ])
} else{ #case where no word follows first_index. Draw second word with prob S
  second_index <- sample(1:length(b), 1, prob = S)
}
simulated_indices <- append(simulated_indices, second_index)

# function to draw words 3 to 50
draw <- function(i,j){ #where i is second predecessor and j the first.
  if (sum(T[i,j, ]) > 0){ #case where a word follows i and j
    index <- sample(1:length(b), 1, prob = T[i,j, ])
  }else if(sum(A[j, ]) > 0){
    index <- sample(1:length(b), 1, prob = A[j, ])
  } else{
    index <- sample(1:length(b), 1, prob = S)
  }
}

#fill up the list with 50 sampled words.
for(k in 3:50){
  print(simulated_indices[k-2])
  index <- draw(simulated_indices[k-2], simulated_indices[k-1])
  simulated_indices <- append(simulated_indices, index)
}
cat(b[simulated_indices])

## Q9 ##

S_indices <- sample(1:length(b), 50, replace = TRUE, prob = S) #draw 50 at once
cat(b[S_indices])

## Q10 ##

# Recall that bible_original has punctuation split out, but is not strictly lower case.
bible_original

# Match a,b, gives the indices in b for each word in a (na if word is not in b)
lower_indices <- match(a,b)

unique_bible <- unique(bible_original)
original_indices <- match(bible_original,unique_bible)

# Create dataframe to compare these two index lists
indices.df<- data.frame(lower_indices, original_indices)

# Needed for distinct function on a dataframe.
library(tidyverse)
## drop duplicates. This gives us the link between lower and original indices
indices.df <- indices.df %>% distinct()

# count occurances of original_indices
original_counts <- table(original_indices)
indices.df['original_counts'] <- original_counts 

## remove na value 
indices.df <- na.omit(indices.df)

#sort ascending on lower_indices.
indices.df <- indices.df[
  order( indices.df[,1], indices.df[,3] ),
]

##for each lower_index, need to keep only the row with the higher original_count

# add a column with the max count for each word 
sorted.df <- indices.df %>%
  group_by(lower_indices) %>% summarise(original_counts = max(original_counts))


merged.df <- merge(indices.df, sorted.df, by="lower_indices")
merged.df <- merged.df %>% rename(original_freq = original_counts.x, max_freq = original_counts.y)

# new column identifying if the word is in most used form (caps/not caps)
merged.df['is_max'] <- (merged.df['original_freq'] == merged.df['max_freq'])

# keep only most used cas
filter.df <- merged.df %>% filter(merged.df['is_max']==TRUE)

# make list of words in most used form
b_print_indices <- dplyr::pull(filter.df, 'original_indices')
b_print <- unique_bible[b_print_indices]

## simulation using b_print (notice the sporadic capitals!)
cat(b_print[simulated_indices])

