# Stat_Prog_Grp_Ass_1
Repository for collaboration on the first group assignment for Statistical Programming. 
