# Scott Jenkins s2451950 
# Practical 5: UK Excess Deaths 2020-22

## This script models the number of deaths v... blah....


## Load in test data
setwd('C:/Users/sjenk/OneDrive/Documents/1-MSc/Statistical_Programming/Stat_Prog_Ind_Ass_5')
deaths_df <- read.table('death1722uk.dat'); ages_df <- read.table('lt1720uk.dat')

head(ages_df)
ages <- ages_df$age ## 0,1,...,100 n: aged between n and n+1, 100: aged over 100
fpop17 <- ages_df$fpop17; mpop17 <- ages_df$mpop17  ## pop by age (start of 2017)
fpop20 <- ages_df$fpop20; mpop20 <- ages_df$mpop20 ## pop by age (start of 2020)
mf <- ages_df$mf; mm <- ages_df$mm  ## Underlying mortality rates by age and gender

head(deaths_df)
weeks <- deaths_df$week ## number of weeks since start of 2020, 1,2,..,305
deaths <- deaths_df$deaths ## observed deaths by week
d <- deaths_df$d ## seasonal weekly adjustment for mortality rate 
  

## Initialisation before making predictions
predicted_deaths_m <- rep(0,length(d)) ## Initialise vector to record expected deaths
predicted_deaths_f <- rep(0,length(d)) 

q_adj_f <- (1-exp(-mf/52))*0.9885  ## female death rate by age with adjustment
q_adj_m <- (1-exp(-mm/52))*0.9885  ## male death rate by age with adjustment

start_pop_m <- mpop17  ## Initialise the starting populations
start_pop_f <- fpop17

num_preds <- length(d) ## the number of predictions to make

## For each week in length of d, make predictions of number of deaths 
for (i in 1:num_preds){
  print(i)
  d_now <- d[i] ## the seasonal mortality multiplier
  
  ## predict male deaths and new population
  D_m <- d_now * q_adj_m * start_pop_m
  predicted_deaths_m[i] <- sum(D_m)  ## Insert prediction into vector
  pop_star_m <- start_pop_m - D_m
  pop_star_shift_m <- head(c(0,pop_star_m),-1)
  start_pop_m <- (51/52)*pop_star_m + (1/52)*pop_star_shift_m
  
  ## predict female deaths and new population
  D_f <- d_now * q_adj_f * start_pop_f
  predicted_deaths_f[i] <- sum(D_f)  ## Insert prediction into vector
  pop_star_f <- start_pop_f - D_f
  pop_star_shift_f <- head(c(0,pop_star_f),-1)
  start_pop_f <- (51/52)*pop_star_f + (1/52)*pop_star_shift_f
  
  i <- i+1   ## move on to next prediction period
}

predicted_deaths <- predicted_deaths_m + predicted_deaths_f  ## sum male and female
predicted_deaths

excess_deaths <-deaths -  predicted_deaths  ## e.g. 100 deaths when only expect 80 is 20 excess
excess_deaths
excess_20_end <- sum(excess_deaths[157:num_preds])   ## 91k excess deaths
excess_20_only <- sum(excess_deaths[157:209])        ## 55k excess deaths

## append predictions to the deaths_df
head(deaths_df)
deaths_df['predicted_deaths'] = predicted_deaths
deaths_df['excess_deaths'] = excess_deaths
deaths_df['cumulative_excess_deaths'] = cumsum(excess_deaths)
head(deaths_df)

### some plots
library(ggplot2)
a <- ggplot(deaths_df, aes(x=week,y=deaths)) + 
  geom_point() + 
  geom_smooth(aes(x=week,y=predicted_deaths)) +
  labs(title='My first GG plot')

a <- a + coord_cartesian(ylim=c(0,30000))
  
a

## plot (cumulative) excess deaths by week

b <- ggplot(deaths_df, aes(x=week,y=excess_deaths)) + geom_point()
b

c <- ggplot(deaths_df, aes(x=week,y=cumulative_excess_deaths)) + geom_point()
c

library(rjags)
# mod <- jags.model("model.jags",data=list())



excess_deaths <- function(mpop, fpop, mm, mf, d){
    ## Inputs
  ## mpop: vector of starting male population by one year age classes
  ## fpop: vector of starting female population by one year age classes
  ## mm: vector of annual male death rates by one year age classes 
  ## mf: vector of annual female death rates by one year age classes 
  ## d: mortality rate a vector to account for seasonal changes in death rate by week 
  
  
  
  ## The function should return the predicted total number of deaths each week as a vector. 
  
  
  
}## excess_deaths function

