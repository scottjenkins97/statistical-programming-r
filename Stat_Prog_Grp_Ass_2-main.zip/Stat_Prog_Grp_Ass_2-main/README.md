# Stat_Prog_Grp_Ass_2
Repository for working on the second group assignment for our Statistical Programming
