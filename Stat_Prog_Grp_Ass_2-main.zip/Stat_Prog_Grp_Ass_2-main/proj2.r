# s1704264 Benedict Troy
# s2451950 Scott Jenkins
# s2453724 Emily Segers

# Github Repo:
# https://github.com/gitgetgot97/Stat_Prog_Grp_Ass_2.git

# Contribution:
# None of us contributed significantly more, or less, than the others. 
# Hence we deserve equal marks on this assignment. 

## The Prisoner Problem Simulation

## 2n prisoners each have a unique prisoner number from 1 to 2n.
## The prison contains a room in which there are 2n boxes, each with a unique number from 1 to 2n painted on its lid.
## 2n cards, each printed with a unique number from 1 to 2n, are randomly placed, one in each box.
## The prisoners have the task of finding the card with their number on it by opening a maximum of n boxes.
## After each prisoner's box-finding attempt, the room is returned exactly to its original state and the prisoner is not allowed to communicate with prisoners yet to have their go.
## If all prisoners succeed in finding the card with their number on it, then they all go free. Otherwise, none of them are released from prison.

## This program simulates three strategies, and compares the prisoner's success likelihood in each. 

## Strategy 1:
#  The prisoner starts at the box with their number on it, opens it and reads the number on the card: k, say. If k
#  is not their prisoner number, they go to box number k, open it and repeat the process until they have either
#  found the card with their number on it, or opened n boxes without finding it.

## Strategy 2:
# As strategy 1, but starting from a randomly selected box.

## Strategy 3:
# They open n boxes at random, checking each card for their number.

########################################################################

pone <- function(n, k, strategy, nreps, a=1){
  ## This function simulates a given strategy, nreps number of times for 
  #  prisoner number k with 2n boxes to search. 
  ## 'a' can be used to pass a specified arrangement of cards, but the default 
  #  value will generate a random permutation of cards
  success_count = 0 ## Initialise count for number of times a prisoner finds their number
  for(i in 1:nreps){
    ## Initialisations for each iteration
    if(length(a)==1){
      ## Default value leads to new random permutation of cards 
      cards <- sample(1:(2*n), 2*n)
    }else{
      ## Pass card arrangement into the function using 'a'
      cards <- a
    }
    ## The index of a number in 'cards' represents the box 
    #  number which the card is in
    boxes_opened <- rep(0,n) ## Initialise a vector to keep track of which boxes have been searched
    success = 0   ## Indicates whether the correct card has been found (0 if no, 1 if yes)
    box_count = 0 ## This will count the number of boxes which have been searched
    
    if (strategy == 3){
      random_boxes <- sample(1:(2*n), n) ## In strategy 3, simultaneous selection of n random boxes to search
      if (k %in% random_boxes){
        success = 1 ## The prisoner succeeds if one of these n boxes contains k
      }
    }else{
      ## Once the first box is chosen, we use the same procedure for strategies 1 and 2
      if(strategy == 2){
        ## In strategy 2, the first box to open is chosen randomly
        search_box = sample(1:(2*n),1) 
      }else{
        ## In strategy 1, the first box the prisoner searches is their prisoner number
        search_box = k   
      }
      
      while (success == 0 && box_count < n) { 
        ## Prisoner looks in boxes until either their number is found or n boxes have been searched
        card_found <- cards[search_box]       ## Read the card in the box
        if (card_found == k){
          success = 1     ## Prisoner found their number, succeeds!
        }
        box_count <- box_count + 1            ## Update box count
        ## Update the vector of boxes which have been searched
        boxes_opened[box_count] <- search_box 
        ## The next box to open is the most recent card number found
        search_box <- card_found 
        while(search_box %in% boxes_opened){
          ## If this box has already been searched, choose a new one randomly
          search_box <- sample(1:(2*n), 1)   
        }
      }
    }
    success_count <- success_count + success  ## Update success count
  }
  ## Calculate the proportion of times that prisoners found their number
  sample_prob <- (success_count/nreps)        
  return(sample_prob)
}

## Use pone to estimate the probability of an individual prisoner finding their number using each strategy
pone_1_p <- pone(50, 1, 1, 10000)
pone_2_p <- pone(50, 1, 2, 10000)
pone_3_p <- pone(50, 1 ,3, 10000)
print(paste('In strategy 1, the prisoner find their number with estimated probability: ', pone_1_p))
print(paste('In strategy 2, the prisoner find their number with estimated probability: ', pone_2_p))
print(paste('In strategy 3, the prisoner find their number with estimated probability: ', pone_3_p))

################################################################################

pall <- function(n,strategy,nreps){
  ## This function simulates 'nreps' different groups of 2n prisoners each employing a given strategy.

  total_success <- 0 ## Initialise count of how many groups of prisoners all find their prisoner numbers and walk free
  for(i in 1:nreps){ ## Simulation for each of the groups
    cards <- sample(1:(2*n), 2*n) ## Initialise a random card arrangement
    ## Found_number is a binary vector of length 2n 
    # which indicates whether each prisoner has found their card
    ## Entry i will be 1 if prisoner i finds number i, 0 otherwise
    found_number <- sapply(1:(2*n), function(x) pone(n, x, strategy, 1, cards))
    if(sum(found_number) == (2*n)){
      ## If all prisoners have found their numbers, add 1 to the success count 
      total_success <- total_success + 1   
    }
  }
  ## Calculate the proportion of times that all prisoners found their number
  sample_prob <- (total_success/nreps)     
  return(sample_prob)
}

## Use pall to estimate the probability of a group of prisoners all finding 
#  their numbers using each strategy

pall_1_5p <- pall(5,1,10000)
## We reduce the number of iterations to compensate for more prisoners ...
pall_1_50p <- pall(50,1,1000) 
pall_2_5p <- pall(5,2,10000)
pall_2_50p <- pall(50,2,1000)
pall_3_5p <- pall(5,3,10000)
pall_3_50p <- pall(50,3,1000)
  
## Print results
print(paste('A group of 10 prisoners using strategy 1, succeed with estimated probability',pall_1_5p, '.Increasing the group size to 100 changes the estimated probability to ', pall_1_50p))
print(paste('A group of 10 prisoners using strategy 2, succeed with estimated probability',pall_2_5p, '.Increasing the group size to 100 changes the estimated probability to ', pall_2_50p))
print(paste('A group of 10 prisoners using strategy 3, succeed with estimated probability',pall_3_5p, '.Increasing the group size to 100 changes the estimated probability to ', pall_3_50p))


## Observations
## It is surprising that strategy 1 has such a high probability of success.
## For an individual prisoner, the probability of 
#  finding your number is 50% for any strategy.
## We might expect that for large groups, the chance of all prisoners
#  finding their number would be almost 0, regardless of strategy.
## Even though the prisoners act independently, 
#  strategy 1 creates dependencies of success between prisoners.

################################################################################


dloops <- function(n, nreps){
  ## For nreps shuffled sets of 2n cards, calculate the lengths 
  #  of all loops within these arrangements. 
  ## Plot the distribution of the longest loop length
  ## Return a vector of length 2n containing the sample 
  #  probability of having a loop of each length
  ## Initialise a vector to count occurrences of each possible loop length
  freq_count <- rep(0, (2*n))
  ## For each iteration, store the length of the longest loop found 
  longest_loops <- rep(0, nreps)  
  ## Binary vector to indicate if the longest loop has length <= 50. 1 if shorter, 0 if not
  under_50 <- rep(0, nreps)                       
  ## Initialise box to search first
  search_box <- 1                                 
  for(j in 1:nreps){ ## For each iteration...
    ## Generate a random permutation of the 2n cards 
    cards <- sample(1:(2*n), (2*n))  
    ## Initialise a vector to keep track of which boxes have been searched
    boxes_opened <- rep(0,(2*n)) 
    ## Initialise vector to store the lengths of the, at most 2n, loops 
    loops <- rep(0, (2*n)) 
    ## Initialise index
    i <- 1                                      
    while(0 %in% boxes_opened){ 
      ## Keep finding loops until every box has been searched
      while(search_box %in% boxes_opened){
        ## Always start a new loop with a box which is not in an explored loop
        search_box <- sample(1:(2*n),1)           
      }
      loop_length <- 0      ## Start counting how long the loop is
      while(!(search_box %in% boxes_opened)){     
        ## Keep searching boxes until the loop is complete
        card_found <- cards[search_box]        ## Search the box 
        boxes_opened[search_box] <- search_box ## Note that it has been searched
        ## The next box to open is the most recent card number found
        search_box <- card_found 
        ## Add 1 to loop length
        loop_length <- loop_length + 1            
      }
      loops[i] <- loop_length   ## Once the loop is done, record its length
      i <- i+1              ## Increment the index, ready to start next loop
    }
    for(k in 1:(2*n)){                            
      if(k %in% loops){## Check if each loop length occurs at least once
        ## If it does occur, add one to the frequency count of that loop length
        freq_count[k] <- freq_count[k] + 1        
      }
    }
    longest_loops[j] <- max(loops) ## Record the longest loop in each iteration
    if(max(loops) <= n){
      under_50[j] <- 1## Indicate that this iteration had no loop longer than 50
    }
  }
  ## All iterations complete, now analyse and plot results
  ## Calculate the sample probability of each loop length occurring at least once
  sample_probs <- freq_count/nreps 
  ## Visualise distribution of longest loops
  hist(longest_loops, main = "Distribution of longest loop length", xlab = "Loop Length", breaks = (n))
  abline(v=n, col="red",lty = 2, lwd=3)
  estimated_success <- sum(under_50)/nreps
  print(paste('The estimated probability of having no loops longer than', n, 'in a set of', (2*n), 'shuffled cards and boxes:', estimated_success))
  return(sample_probs)
}

## simulate for n=50
d_loop_50 <- dloops(50,10000)

# Visualise probability of each loop length occurring at least once
plot(d_loop_50, main="Probability of each loop length occurring", xlab = "Loop Length", ylab = "Sample Probability")
